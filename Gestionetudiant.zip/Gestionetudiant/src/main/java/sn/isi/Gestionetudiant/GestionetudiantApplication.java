package sn.isi.Gestionetudiant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionetudiantApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionetudiantApplication.class, args);
	}

}
